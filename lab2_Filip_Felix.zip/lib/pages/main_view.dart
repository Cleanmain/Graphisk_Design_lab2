import 'package:flutter/material.dart';
import 'package:lab2/ui_controller.dart';
import 'package:lab2/widgets/difficulty_control.dart';
import 'package:lab2/widgets/ingredient_control.dart';
import 'package:lab2/widgets/kitchen_control.dart';
import 'package:lab2/widgets/price_control.dart';
import 'package:lab2/widgets/recipe_area.dart';
import 'package:lab2/widgets/time_control.dart';
import 'package:provider/provider.dart';

class MainView extends StatelessWidget {
  const MainView({super.key});

  @override
  Widget build(BuildContext context) {
    var uiController = Provider.of<UIController>(context, listen: false);
    return Scaffold(
      body: Row(
        children: [
          _controlPanel(context), RecipeArea()
        ],
      ),
    );
  }

  Widget _controlPanel(BuildContext context, {double width = 320}) {
    return Container(
      width: width,
      color: const Color.fromARGB(255, 193, 210, 218),
      child: Column(
        children: [
          const Text('Receptsök'),
          const Text(
            'Hitta ett recept som passar dig!',
          ),
          const SizedBox(height: 20),
          Row(
            children: const [
              Text('Ingrediens:'),
              IngredientControl(),
            ],
          ),
          Row(
            children: const [
              Text('Kök:'),
              KitchenControl(),
            ],
          ),
          const SizedBox(height: 20),
          const Text('Svårighetsgrad:'),
          const DifficulyControl(),
          const SizedBox(height: 20),
          Row(
            children: const [
              Text('Maxpris:'),
              PriceControl(),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: const [
              Text('Maxtid:'),
              TimeControl(),
            ],
          ),
        ],
      ),
    );
  }
}